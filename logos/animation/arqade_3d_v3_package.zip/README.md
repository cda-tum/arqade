# ARQADE procedural 3D loading loop — v2

This package is generated from the supplied `source.svg`. Geometry is vector-derived end-to-end; there is **no raster trace** in the modeling pipeline.

## What changed in v2

- Native SVG Bézier/stroke geometry is flattened to paths with Inkscape, not rasterized.
- SVGs are imported at 4× physical size and scaled back in OpenSCAD to force finer curve tessellation; this removes the stair-step look on diagonals such as the `A`.
- The model is kept exactly level: `pitch = 0°`, `roll = 0°`; the animation is yaw about world `+Y` only.
- Front and back use separate, correctly wound meshes so PBR lighting is symmetric on both sides.
- Face painter order is preserved procedurally: white letter outline → black gap → blue fill, while the white `Q` core is the top layer as in the source SVG.
- Side/body material is PBR chrome (`metallic=1.0`, `roughness=0.095`).
- Lighting is procedural: an equirectangular studio-reflection environment plus key/fill/rim lights. No generative-image step is used.
- The final movie is a 4.0 s, 120-frame, 30 fps, 1920×1080 seamless 360° loop.

## Main outputs

- `arqade_loading_v2_1080p.mp4` — H.264 render, 1920×1080, 30 fps, 4 s.
- `arqade_loading_v2_1080p.webm` — VP9 version.
- `arqade_loading_v2_preview.gif` — lightweight preview.
- `arqade_loader_v2_animated.glb` — PBR 3D model with a 4 s 360° Y-axis animation.
- `arqade_loader_v2_pbr.glb` — static PBR model.
- `arqade_loader_v2.scad` — procedural OpenSCAD model.
- `render_v2.py` — deterministic VTK PBR renderer.
- `build_geometry_v2.py` — rebuilds vector layers and STLs from `source.svg`.
- `build_glb_v2.py` — rebuilds static and animated PBR GLBs.

## Geometry / animation parameters

- Logo width: 180 mm
- Core depth: 15 mm
- Face layer thickness: 0.32 mm
- Layer spacing: 0.07 mm
- SVG tessellation multiplier: 4×
- Rotation: `R_y(theta)`, `theta = 360° * frame / 120`
- Pitch: 0°
- Roll: 0°

## Rebuild

System tools:

- Inkscape 1.4+
- OpenSCAD
- FFmpeg

Python packages are listed in `requirements.txt`.

```bash
python build_geometry_v2.py
python build_glb_v2.py
python render_v2.py controls
python render_v2.py sequence

ffmpeg -framerate 30 -i frames_v2/frame_%04d.png \
  -c:v libx264 -preset slow -crf 16 -pix_fmt yuv420p \
  -movflags +faststart arqade_loading_v2_1080p.mp4
```

For limited render runtimes, `render_v2.py` can render chunks while keeping the exact global loop phase:

```bash
python render_v2.py range 0 30 120
python render_v2.py range 30 60 120
python render_v2.py range 60 90 120
python render_v2.py range 90 120 120
```

## Notes

The Chrome appearance in the GLB depends on the viewer's environment map, as all true metallic PBR materials do. The supplied video is rendered with `studio_env_v2.png`, generated procedurally by `render_v2.py`.


V3 tweaks (2026-10-06)
- ARQADE blue target updated to sRGB #3170B3FF. In the VTK/glTF PBR pipeline this is encoded as linear RGB [0.0307, 0.1620, 0.4508].
- Chrome body made more reflective/classic-chrome: baseColorFactor [0.94, 0.95, 0.98, 1.0], metallic=1.0, roughness=0.022.
- Reflection-card environment strengthened and coat increased for brighter chrome reflections.
- Representative updated control renders: control_000.png and control_045.png.
