// Munich Quantum ARQADE — procedural 3D loader v2
// Native SVG Bézier geometry, no raster tracing.
// Units: millimeters.

logo_width_mm = 180;
body_depth = 15;
face_thickness = 0.32;
face_gap = 0.025;
layer_step = 0.07;
spin = is_undef(spin) ? 360*$t : spin;
part = is_undef(part) ? "scene" : part;

// The flattened SVG files use 4x physical dimensions solely to force finer
// curve tessellation in OpenSCAD. The final model is scaled back to 180 mm.
svg_supersample = 4;
px_to_mm = 25.4/96;
visible_width_px = 1224;
center_x_px = 705;
center_y_px = 730;
scale_xy = logo_width_mm / (visible_width_px * px_to_mm * svg_supersample);
center_x_mm = center_x_px * px_to_mm * svg_supersample;
center_y_mm = center_y_px * px_to_mm * svg_supersample;

$fa = 0.35;
$fs = 0.08;
$fn = 192;

module svg2d(file) {
    scale([scale_xy, scale_xy])
        translate([-center_x_mm, -center_y_mm])
            import(file=file, dpi=96, convexity=40);
}

module core() {
    linear_extrude(height=body_depth, center=true, convexity=40)
        svg2d("vectors_native/body_flat.svg");
}

module cap_front(file) {
    linear_extrude(height=face_thickness, center=false, convexity=40)
        svg2d(file);
}
module cap_back(file) {
    mirror([0,0,1])
        linear_extrude(height=face_thickness, center=false, convexity=40)
            svg2d(file);
}

module stacked_pair(file, level=0) {
    z = body_depth/2 + face_gap + level*layer_step;
    translate([0,0, z]) cap_front(file);
    translate([0,0,-z]) cap_back(file);
}

module white_letters() { stacked_pair("vectors_native/face_white_letters_flat.svg", 0); }
module black_gaps()    { stacked_pair("vectors_native/face_black_flat.svg", 1); }
module blue_faces()    { stacked_pair("vectors_native/face_blue_flat.svg", 2); }
module q_white()       { stacked_pair("vectors_native/face_q_white_flat.svg", 3); }

module logo() {
    color([0.80,0.84,0.91]) core();
    color([0.985,0.99,1.00]) white_letters();
    color([0.0045,0.006,0.012]) black_gaps();
    color([0.055,0.245,0.88]) blue_faces();
    color([0.985,0.99,1.00]) q_white();
}

// Scene animation: ONLY yaw. Pitch = 0°, roll = 0° by construction.
if (part == "scene") {
    rotate([0, spin, 0]) logo();
} else if (part == "body") {
    core();
} else if (part == "white_letters_front") {
    cap_front("vectors_native/face_white_letters_flat.svg");
} else if (part == "black_front") {
    cap_front("vectors_native/face_black_flat.svg");
} else if (part == "blue_front") {
    cap_front("vectors_native/face_blue_flat.svg");
} else if (part == "qwhite_front") {
    cap_front("vectors_native/face_q_white_flat.svg");
} else if (part == "white_letters_back") {
    cap_back("vectors_native/face_white_letters_flat.svg");
} else if (part == "black_back") {
    cap_back("vectors_native/face_black_flat.svg");
} else if (part == "blue_back") {
    cap_back("vectors_native/face_blue_flat.svg");
} else if (part == "qwhite_back") {
    cap_back("vectors_native/face_q_white_flat.svg");
}
