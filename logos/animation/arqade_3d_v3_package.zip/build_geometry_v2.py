from __future__ import annotations
from pathlib import Path
from copy import deepcopy
import subprocess
from lxml import etree

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'source.svg'
VEC = ROOT / 'vectors_native'
STL = ROOT / 'stl_parts'
SCAD = ROOT / 'arqade_loader_v2.scad'
VEC.mkdir(exist_ok=True)
STL.mkdir(exist_ok=True)

parser = etree.XMLParser(remove_blank_text=False, huge_tree=True)
tree = etree.parse(str(SRC), parser)

def local(e):
    return e.tag.split('}')[-1] if isinstance(e.tag, str) else ''

def extract(name: str, selected: set[str]):
    t = deepcopy(tree)
    r = t.getroot()
    for e in list(r):
        if local(e) in ('metadata', 'namedview'):
            r.remove(e)

    def prune(e):
        if local(e) == 'defs':
            return True
        if e.get('id') in selected:
            return True
        kept = False
        for c in list(e):
            if not isinstance(c.tag, str):
                e.remove(c)
            elif prune(c):
                kept = True
            else:
                e.remove(c)
        return kept

    for e in list(r):
        if local(e) == 'defs':
            continue
        if not prune(e):
            r.remove(e)
    for e in r.xpath('.//*[@id="background-fill"]'):
        e.getparent().remove(e)

    raw = VEC / f'{name}.svg'
    flat = VEC / f'{name}_flat.svg'
    t.write(str(raw), xml_declaration=True, encoding='UTF-8', pretty_print=True)

    # Vector-only flattening: resolve clones, convert strokes to paths, convert
    # objects to paths. No rasterization occurs anywhere in this pipeline.
    actions = (
        'select-all;clone-unlink-recursively;select-all;object-stroke-to-path;'
        'select-all;object-to-path;export-area-page;export-plain-svg:true;'
        f'export-filename:{flat};export-do'
    )
    subprocess.run(['inkscape', str(raw), f'--actions={actions}'], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # 4x physical SVG dimensions force finer OpenSCAD curve tessellation while
    # preserving the same viewBox/path coordinates. SCAD scales it back down.
    ft = etree.parse(str(flat))
    fr = ft.getroot()
    fr.set('width', '5600')
    fr.set('height', '5600')
    ft.write(str(flat), xml_declaration=True, encoding='UTF-8', pretty_print=True)
    print('vector', flat.name)

white_letters = {'A1-outline','R-outline','A2-outline','D-outline','E-outline','text1'}
q_white = {'q-ring-core','q-swoosh-core'}
black = {'A1-gap','R-gap','A2-gap','D-gap','E-gap','q-ring-gap','q-swoosh-gap','g6'}
blue = {'A1-fill','R-fill','A2-fill','D-fill','E-fill','g8'}
body = white_letters | q_white | blue

extract('face_white_letters', white_letters)
extract('face_q_white', q_white)
extract('face_black', black)
extract('face_blue', blue)
extract('body', body)

parts = [
    'body',
    'white_letters_front','black_front','blue_front','qwhite_front',
    'white_letters_back','black_back','blue_back','qwhite_back',
]
for part in parts:
    out = STL / f'part_{part}.stl'
    subprocess.run([
        'openscad', '-o', str(out), '-D', f'part="{part}"', str(SCAD)
    ], cwd=str(ROOT), check=True)
    print('mesh', out.name)
