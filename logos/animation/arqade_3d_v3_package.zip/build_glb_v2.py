from pathlib import Path
import json, struct, math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

ROOT=Path(__file__).resolve().parent
STL=ROOT/'stl_parts'
BODY_HALF=7.5
LAYER_Z={
    'white_letters': BODY_HALF+0.025,
    'black': BODY_HALF+0.095,
    'blue': BODY_HALF+0.165,
    'qwhite': BODY_HALF+0.235,
}

materials={
    'body': PBRMaterial(name='Glossy Chrome', baseColorFactor=[0.94,0.95,0.98,1.0], metallicFactor=1.0, roughnessFactor=0.022),
    'white_letters': PBRMaterial(name='White Face', baseColorFactor=[0.985,0.99,1.0,1.0], metallicFactor=0.08, roughnessFactor=0.16),
    'black': PBRMaterial(name='Black Gap', baseColorFactor=[0.0045,0.006,0.012,1.0], metallicFactor=0.22, roughnessFactor=0.25),
    'blue': PBRMaterial(name='Arqade Blue', baseColorFactor=[0.0307,0.1620,0.4508,1.0], metallicFactor=0.06, roughnessFactor=0.24),
    'qwhite': PBRMaterial(name='Q White Face', baseColorFactor=[0.985,0.99,1.0,1.0], metallicFactor=0.08, roughnessFactor=0.14),
}

def load_mesh(path):
    m=trimesh.load_mesh(path, process=True)
    if isinstance(m,trimesh.Scene):
        m=trimesh.util.concatenate(tuple(m.geometry.values()))
    return m

scene=trimesh.Scene()
body=load_mesh(STL/'part_body.stl')
body.apply_scale(0.001)  # mm -> meters
body.visual=TextureVisuals(material=materials['body'])
scene.add_geometry(body, geom_name='chrome_body', node_name='chrome_body')

for name,z in LAYER_Z.items():
    f=load_mesh(STL/f'part_{name}_front.stl')
    b=load_mesh(STL/f'part_{name}_back.stl')
    f.apply_translation([0,0,z])
    b.apply_translation([0,0,-z])
    m=trimesh.util.concatenate([f,b])
    m.apply_scale(0.001)
    m.visual=TextureVisuals(material=materials[name])
    scene.add_geometry(m, geom_name=name, node_name=name)

static_path=ROOT/'arqade_loader_v2_pbr.glb'
static_path.write_bytes(scene.export(file_type='glb'))
print('wrote', static_path, static_path.stat().st_size)

# Add a deterministic 4 s / 360° Y-axis animation to a parent node.
def read_glb(path):
    data=path.read_bytes()
    magic,version,total=struct.unpack_from('<4sII',data,0)
    assert magic==b'glTF' and version==2 and total==len(data)
    off=12; js=None; binbuf=b''
    while off < len(data):
        n,typ=struct.unpack_from('<II',data,off); off+=8
        chunk=data[off:off+n]; off+=n
        if typ==0x4E4F534A: js=json.loads(chunk.rstrip(b' \t\r\n\x00').decode('utf-8'))
        elif typ==0x004E4942: binbuf=chunk
    return js,binbuf

def pad4_bytes(b, pad=b'\x00'):
    return b + pad*((-len(b))%4)

def write_glb(path, js, binbuf):
    jb=json.dumps(js,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    jb=pad4_bytes(jb,b' ')
    bb=pad4_bytes(binbuf,b'\x00')
    total=12+8+len(jb)+(8+len(bb) if bb else 0)
    out=bytearray(struct.pack('<4sII',b'glTF',2,total))
    out += struct.pack('<II',len(jb),0x4E4F534A)+jb
    if bb:
        out += struct.pack('<II',len(bb),0x004E4942)+bb
    path.write_bytes(out)

js,binbuf=read_glb(static_path)
scenes=js.setdefault('scenes',[{'nodes':[]}])
base_nodes=list(scenes[js.get('scene',0)].get('nodes',[]))
root_index=len(js.setdefault('nodes',[]))
js['nodes'].append({'name':'LogoRoot','children':base_nodes})
scenes[js.get('scene',0)]['nodes']=[root_index]

# Five quaternion keyframes prevent the 360° endpoint from collapsing to the
# zero-rotation quaternion under shortest-path interpolation.
times=np.array([0,1,2,3,4],dtype='<f4')
angles=np.deg2rad([0,90,180,270,360])
rots=np.stack([np.zeros(5),np.sin(angles/2),np.zeros(5),np.cos(angles/2)],axis=1).astype('<f4')

binbuf=pad4_bytes(binbuf)
time_off=len(binbuf); binbuf += times.tobytes(); binbuf=pad4_bytes(binbuf)
rot_off=len(binbuf); binbuf += rots.tobytes(); binbuf=pad4_bytes(binbuf)

bvs=js.setdefault('bufferViews',[])
time_bv=len(bvs); bvs.append({'buffer':0,'byteOffset':time_off,'byteLength':times.nbytes})
rot_bv=len(bvs); bvs.append({'buffer':0,'byteOffset':rot_off,'byteLength':rots.nbytes})
acc=js.setdefault('accessors',[])
time_acc=len(acc); acc.append({'bufferView':time_bv,'componentType':5126,'count':len(times),'type':'SCALAR','min':[0.0],'max':[4.0]})
rot_acc=len(acc); acc.append({'bufferView':rot_bv,'componentType':5126,'count':len(rots),'type':'VEC4'})
js.setdefault('animations',[]).append({
    'name':'ARQADE_360_Loop',
    'samplers':[{'input':time_acc,'output':rot_acc,'interpolation':'LINEAR'}],
    'channels':[{'sampler':0,'target':{'node':root_index,'path':'rotation'}}]
})
js.setdefault('buffers',[{}])[0]['byteLength']=len(binbuf)
anim_path=ROOT/'arqade_loader_v2_animated.glb'
write_glb(anim_path,js,binbuf)
print('wrote', anim_path, anim_path.stat().st_size)

# Structural verification + geometry round trip.
check_js,check_bin=read_glb(anim_path)
assert check_js['animations'][0]['name']=='ARQADE_360_Loop'
assert check_js['animations'][0]['channels'][0]['target']['node']==root_index
assert check_js['buffers'][0]['byteLength']<=len(check_bin)
loaded=trimesh.load(anim_path, force='scene')
print('verified geometries', list(loaded.geometry.keys()))
print('bounds m', loaded.bounds.tolist())
