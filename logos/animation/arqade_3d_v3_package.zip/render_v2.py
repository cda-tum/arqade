from pathlib import Path
import math, os, sys, time
import numpy as np
from PIL import Image, ImageFilter, ImageEnhance
import vtk

ROOT = Path(__file__).resolve().parent
STL = ROOT / 'stl_parts'
FRAMES = ROOT / 'frames_v2'
FRAMES.mkdir(exist_ok=True)

# Render configuration
OUT_W, OUT_H = 1920, 1080
RENDER_SCALE = 1.25   # supersample then Lanczos-downsample
RW, RH = int(OUT_W*RENDER_SCALE), int(OUT_H*RENDER_SCALE)
FPS = 30
NFRAMES = 120
BODY_HALF = 7.5
CAP_T = 0.32
# Stack face layers outward so they never coplanarly z-fight.
LAYER_Z = {'white_letters': BODY_HALF + 0.025, 'black': BODY_HALF + 0.095, 'blue': BODY_HALF + 0.165, 'qwhite': BODY_HALF + 0.235}

# Visual center measured from native-vector mesh bounds. Rotation axis stays world +Y.
TARGET_Y = -8.87225

# Procedural studio environment for chrome reflections.
def make_environment(path: Path, W=2048, H=1024):
    xx = np.linspace(0.0, 1.0, W)
    yy = np.linspace(0.0, 1.0, H)
    img = np.zeros((H,W,3), np.float32)
    # deep neutral/navy studio
    img[:] = (0.010, 0.012, 0.020)
    # Broad and narrow reflection cards around the logo.
    cards = [
        (0.055, 1.65, 0.012, (1.00,1.00,1.00), 0.44,0.24),
        (0.175, 0.55, 0.034, (0.16,0.34,0.95), 0.48,0.31),
        (0.315, 1.05, 0.022, (0.97,0.98,1.00), 0.42,0.27),
        (0.510, 0.42, 0.050, (0.10,0.24,0.80), 0.50,0.34),
        (0.665, 1.55, 0.013, (1.00,0.99,0.95), 0.44,0.23),
        (0.790, 0.58, 0.032, (0.14,0.38,0.98), 0.50,0.31),
        (0.930, 1.25, 0.019, (0.93,0.97,1.00), 0.46,0.25),
    ]
    for cx, amp, sx, col, cy, sy in cards:
        dx = np.minimum(np.abs(xx-cx), 1-np.abs(xx-cx))
        gx = np.exp(-0.5*(dx/sx)**2)[None,:,None]
        gy = np.exp(-0.5*((yy-cy)/sy)**2)[:,None,None]
        img += amp*gx*gy*np.asarray(col)[None,None,:]
    # Soft cool horizon / lower fill.
    img += 0.20*np.exp(-0.5*((yy-0.66)/0.10)**2)[:,None,None]*np.asarray([0.08,0.18,0.55])[None,None,:]
    # Keep LDR environment but preserve bright cards.
    img = np.clip(img,0,1)
    Image.fromarray((img**(1/2.2)*255).astype(np.uint8),'RGB').save(path)

def make_actor(path, color, metallic, roughness, feature_angle=28):
    reader = vtk.vtkSTLReader(); reader.SetFileName(str(path)); reader.Update()
    normals = vtk.vtkPolyDataNormals(); normals.SetInputConnection(reader.GetOutputPort())
    normals.ConsistencyOn(); normals.AutoOrientNormalsOn(); normals.SplittingOn(); normals.SetFeatureAngle(feature_angle)
    normals.ComputePointNormalsOn(); normals.ComputeCellNormalsOn(); normals.Update()
    mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(normals.GetOutputPort())
    actor = vtk.vtkActor(); actor.SetMapper(mapper)
    prop = actor.GetProperty(); prop.SetInterpolationToPBR(); prop.SetColor(*color)
    prop.SetMetallic(metallic); prop.SetRoughness(roughness)
    if hasattr(prop,'SetCoatStrength'):
        prop.SetCoatStrength(0.45 if metallic > 0.8 else 0.14)
        prop.SetCoatRoughness(0.018 if metallic > 0.8 else 0.05)
    return actor

def build_scene():
    env_path = ROOT/'studio_env_v2.png'
    if not env_path.exists(): make_environment(env_path)
    ren = vtk.vtkRenderer(); ren.SetBackground(0.0025,0.0045,0.010)
    ren.UseImageBasedLightingOn()
    rr = vtk.vtkPNGReader(); rr.SetFileName(str(env_path)); rr.Update()
    tex = vtk.vtkTexture(); tex.SetInputConnection(rr.GetOutputPort()); tex.MipmapOn(); tex.InterpolateOn(); tex.SetColorModeToDirectScalars()
    if hasattr(tex,'SetUseSRGBColorSpace'): tex.SetUseSRGBColorSpace(True)
    ren.SetEnvironmentTexture(tex, True)

    root = vtk.vtkAssembly()
    body = make_actor(STL/'part_body.stl', (0.94,0.95,0.98), 1.0, 0.022, 34)
    root.AddPart(body)

    specs = {
        'white_letters': ((0.985,0.99,1.00), 0.08, 0.16),
        'black': ((0.0045,0.006,0.012), 0.22, 0.25),
        'blue':  ((0.0307,0.1620,0.4508), 0.06, 0.24),
        'qwhite': ((0.985,0.99,1.00), 0.08, 0.14),
    }
    for name,(color,metal,rough) in specs.items():
        z=LAYER_Z[name]
        front = make_actor(STL/f'part_{name}_front.stl', color, metal, rough, 25)
        front.SetPosition(0,0,z)
        root.AddPart(front)
        back = make_actor(STL/f'part_{name}_back.stl', color, metal, rough, 25)
        back.SetPosition(0,0,-z)
        root.AddPart(back)
    ren.AddActor(root)

    # Key, fill, rim. These illuminate diffuse faces while the environment drives chrome reflections.
    light_specs=[
        ((-145, 85, 145), (0.62,0.74,1.00), 4.3, 72),
        (( 155, 45, 110), (1.00,0.92,0.82), 3.8, 68),
        ((   0,120,  35), (0.40,0.56,1.00), 2.9, 80),
        ((   0,-95,  80), (0.18,0.30,0.75), 1.7, 82),
    ]
    for pos,color,intensity,cone in light_specs:
        l=vtk.vtkLight(); l.SetLightTypeToSceneLight(); l.SetPosition(*pos); l.SetFocalPoint(0,TARGET_Y,0)
        l.SetColor(*color); l.SetIntensity(intensity); l.PositionalOn(); l.SetConeAngle(cone); ren.AddLight(l)

    cam=ren.GetActiveCamera(); cam.SetPosition(0,TARGET_Y,265); cam.SetFocalPoint(0,TARGET_Y,0); cam.SetViewUp(0,1,0); cam.SetViewAngle(29.5)
    cam.SetClippingRange(1,1000)

    win=vtk.vtkRenderWindow(); win.SetOffScreenRendering(1); win.SetMultiSamples(8); win.SetSize(RW,RH); win.AddRenderer(ren)
    if hasattr(win,'SetUseOffScreenBuffers'): win.SetUseOffScreenBuffers(True)
    return ren, root, win

def capture(win, tmp_path):
    win.Render()
    w2i=vtk.vtkWindowToImageFilter(); w2i.SetInput(win); w2i.SetInputBufferTypeToRGB(); w2i.ReadFrontBufferOff(); w2i.Update()
    w=vtk.vtkPNGWriter(); w.SetFileName(str(tmp_path)); w.SetInputConnection(w2i.GetOutputPort()); w.Write()

def postprocess(src: Path, dst: Path):
    im=Image.open(src).convert('RGB')
    # Downsample high-res render to smooth all silhouette diagonals and fine curves.
    im=im.resize((OUT_W,OUT_H), Image.Resampling.LANCZOS)
    arr=np.asarray(im).astype(np.float32)/255.0
    # Gentle cinematic background vignette without changing the actual geometry/material render.
    yy,xx=np.mgrid[0:OUT_H,0:OUT_W]
    nx=(xx-OUT_W/2)/(OUT_W/2); ny=(yy-OUT_H/2)/(OUT_H/2)
    r=np.sqrt(nx*nx+ny*ny)
    vign=np.clip(1.05-0.28*np.maximum(r-0.18,0),0.74,1.05)[...,None]
    arr=np.clip(arr*vign,0,1)
    base=Image.fromarray((arr*255).astype(np.uint8),'RGB')
    # Small physically-inspired bloom from specular highlights; no geometry alteration.
    lum=np.asarray(base).astype(np.float32).max(axis=2)/255.0
    mask=np.clip((lum-0.72)/0.28,0,1)
    glow=np.asarray(base).astype(np.float32)*mask[...,None]
    glow_img=Image.fromarray(np.clip(glow,0,255).astype(np.uint8),'RGB').filter(ImageFilter.GaussianBlur(13))
    b=np.asarray(base).astype(np.float32)/255.0
    g=np.asarray(glow_img).astype(np.float32)/255.0
    base=Image.fromarray(np.clip((b + 0.22*g)*255.0,0,255).astype(np.uint8),'RGB')
    base=ImageEnhance.Contrast(base).enhance(1.045)
    base=ImageEnhance.Sharpness(base).enhance(1.08)
    base.save(dst, quality=96)

def render_angle(angle, outpath):
    ren, root, win = build_scene()
    root.SetOrientation(0,float(angle),0)  # pitch=0, yaw=angle, roll=0
    tmp=ROOT/'_tmp_render.png'; capture(win,tmp); postprocess(tmp,outpath)
    win.Finalize()
    try: tmp.unlink()
    except: pass

def render_range(start_i, end_i, total=NFRAMES):
    ren, root, win = build_scene(); tmp=ROOT/f'_tmp_render_{os.getpid()}.png'
    t0=time.time()
    for i in range(start_i,end_i):
        angle=360.0*i/total
        root.SetOrientation(0,angle,0)
        capture(win,tmp)
        postprocess(tmp, FRAMES/f'frame_{i:04d}.png')
        if (i-start_i)%5==0 or i==end_i-1:
            print(f'{i}/{total-1} angle={angle:.1f} elapsed={time.time()-t0:.1f}s', flush=True)
    win.Finalize()
    try: tmp.unlink()
    except: pass

def render_sequence():
    render_range(0,NFRAMES,NFRAMES)

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'controls'
    if mode=='controls':
        for a in (0,45,90):
            render_angle(a, ROOT/f'control_{a:03d}.png')
            print('wrote',ROOT/f'control_{a:03d}.png')
    elif mode=='sequence':
        render_sequence()
    elif mode=='range':
        render_range(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]) if len(sys.argv)>4 else NFRAMES)
    else:
        render_angle(float(mode), ROOT/f'control_{int(float(mode)):03d}.png')
